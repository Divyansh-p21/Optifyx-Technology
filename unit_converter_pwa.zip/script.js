const input = document.getElementById("inputValue");
const inputUnit = document.getElementById("inputUnit");
const outputUnit = document.getElementById("outputUnit");
const result = document.getElementById("result");

input.addEventListener("input", convert);
inputUnit.addEventListener("change", convert);
outputUnit.addEventListener("change", convert);

function convert() {
  const value = parseFloat(input.value);
  if (isNaN(value)) {
    result.textContent = "";
    return;
  }

  const conversions = {
    meter: { meter: 1, kilometer: 0.001, mile: 0.000621371 },
    kilometer: { meter: 1000, kilometer: 1, mile: 0.621371 },
    mile: { meter: 1609.34, kilometer: 1.60934, mile: 1 },
  };

  const convertedValue = value * conversions[inputUnit.value][outputUnit.value];
  result.textContent = `${value} ${inputUnit.value} = ${convertedValue.toFixed(4)} ${outputUnit.value}`;
}