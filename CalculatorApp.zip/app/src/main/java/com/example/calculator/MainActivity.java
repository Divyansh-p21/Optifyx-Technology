
package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView display;
    String input = "", operator = "";
    double num1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
    }

    public void onNumberClick(View v) {
        Button b = (Button) v;
        input += b.getText().toString();
        display.setText(input);
    }

    public void onOperatorClick(View v) {
        Button b = (Button) v;
        operator = b.getText().toString();
        num1 = Double.parseDouble(input);
        input = "";
    }

    public void onEqualClick(View v) {
        double num2 = Double.parseDouble(input);
        double result = 0;
        switch (operator) {
            case "+": result = num1 + num2; break;
            case "-": result = num1 - num2; break;
            case "*": result = num1 * num2; break;
            case "/": result = num1 / num2; break;
        }
        display.setText(String.valueOf(result));
        input = "";
    }

    public void onClearClick(View v) {
        input = "";
        num1 = 0;
        operator = "";
        display.setText("");
    }
}
